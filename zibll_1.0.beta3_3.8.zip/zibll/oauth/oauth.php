<?php

function get_oauth_config($type='qq')
{
    $args = array(
        'appid' => _pz('oauth_'.$type.'_appid'),
        'appkey' => _pz('oauth_'.$type.'_appkey'),
        'backurl' => esc_url(home_url('/oauth/'.$type.'/callback')),
        'agent' => _pz('oauth_'.$type.'_agent',false),
    );
    return $args;
}

function get_oauth_config_weibo($type='qq')
{
    $args = array(
        'appid' => _pz('oauth_qq_appid'),
        'appkey' => _pz('oauth_qq_appkey'),
        'backurl' => _pz('oauth_qq_backurl'),
        'agent' => _pz('oauth_qq_agent'),
    );
    return $args;
}

