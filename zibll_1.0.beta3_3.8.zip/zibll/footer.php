<?php if (!is_user_logged_in()) {
	zib_sign_modal();
} else {
	zib_signout_modal();
} ?>

<div class="notyn"></div>
<footer class="footer">
	<?php if (function_exists('dynamic_sidebar')) {
		dynamic_sidebar('all_footer');
	} ?>
	<div class="container-fluid container-footer">
	<?php zib_footer_con();?>
	</div>
</footer>
<?php
zib_float_right();
zib_system_notice();
wp_footer();
 ?>
</body>
</html>