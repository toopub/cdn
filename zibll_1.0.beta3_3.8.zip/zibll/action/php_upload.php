<?php

//上传图像
function php_upload($file='file')
{
    require dirname(__FILE__) . '/../../../../wp-load.php';
    if (!$_FILES) {
        return false;
    }

    if ($_FILES) {
        $files = $_FILES[$file];
        require_once(ABSPATH . "wp-admin" . '/includes/image.php');
        require_once(ABSPATH . "wp-admin" . '/includes/file.php');
        require_once(ABSPATH . "wp-admin" . '/includes/media.php');
            $attach_id = media_handle_upload($file, 0);
        if (is_wp_error($attach_id)) {
            print_r(json_encode(array('error' => 1, '_FILES' => $_FILES ,'ys' => 'warning',  'is_wp_error' => $attach_id, 'msg' => '上传出错，请稍候再试')));
            exit();
        } else {
            return $attach_id;
        }
    }
}
